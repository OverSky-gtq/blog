#include "serviceinfo.h"
#include "ui_serviceinfo.h"

serviceInfo::serviceInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::serviceInfo)
{
    ui->setupUi(this);
    m_Model = new QStandardItemModel(ui->tableView);
    m_Model->setHorizontalHeaderLabels(QStringList() << "姓名" << "身份证号"<< "座位号");

    m_FilterModel = new QSortFilterProxyModel(ui->tableView);
    m_FilterModel->setSourceModel(m_Model);
    m_FilterModel->setFilterKeyColumn(2);

    ui->tableView->setSortingEnabled(true);   //可通过点击表头实现排序
    ui->tableView->setModel(m_FilterModel);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows); //只能选取单行
    ui->tableView->setColumnWidth(1,220);//调整身份证列视图，以便完整显示
}

serviceInfo::~serviceInfo()
{
    delete ui;
}

void serviceInfo::process_mainwindow_serviceinfo(Service a, passenger b,int c)
{
    ser = a;
    user = b;
    priority = c;

    ui->spinBox->setRange(1,a.m_numOfTicket); //设置可选座位范围
    this->setWindowTitle(a.m_serviceId + "班次详情");//设置窗口标题

    ui->serId->setText(a.m_serviceId);
    ui->city->setText(a.m_destination);
    ui->time->setText(a.m_startTime.toString("yyyy-MM-dd hh:mm"));
    ui->price->setText(QString::number(a.m_price));
    ui->ticket->setText(QString::number(a.getLeftTicket())+'/'+QString::number(a.m_numOfTicket));
    ui->comment->setText(a.m_comment);   //重新展示此班次信息

    if(priority == 1)
    {
        for(int i = 0;i<ser.seat.size();++i)
        {
            m_Model->appendRow(QList<QStandardItem *>()
                               <<new QStandardItem(ser.seat[i].m_name)
                               <<new QStandardItem(ser.seat[i].m_id)
                               <<new QStandardItem(QString::number(ser.seat[i].m_seatId)));
        }

    }
    else
    {
        for(int i = 0;i<ser.seat.size();++i)
        {
            m_Model->appendRow(QList<QStandardItem *>()
                               <<new QStandardItem("无权查看")
                               <<new QStandardItem("无权查看")
                               <<new QStandardItem(QString::number(ser.seat[i].m_seatId)));
        }
        ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);  //非管理员设置只读
    }

}


void serviceInfo::on_buyTicket_clicked()
{
    bool isRepeat = false;
    for(int i = 0;i<ser.seat.size();++i) //检测此座位是否已经有人
    {
        if(ser.seat[i].m_seatId == ui->spinBox->text().toInt())
        {
            isRepeat = true;
            break;
        }

    }
    if(!isRepeat)
    {
        user.m_seatId = ui->spinBox->text().toInt();
        ser.seat.push_back(user);
        m_Model->appendRow(QList<QStandardItem *>()
                       <<new QStandardItem(user.m_name)
                       <<new QStandardItem(user.m_id)
                       <<new QStandardItem(QString::number(user.m_seatId)));
        emit serviceinfo_mainwindow(ser);
    }
    else
    {
        QMessageBox::critical(this,"座位信息","此座位已经被预定！");
    }
}


void serviceInfo::on_returnTicket_clicked()
{
    user.m_seatId = ui->spinBox->text().toInt();
    for(int i = 0;i<ser.seat.size();++i)
    {
        if(ser.seat[i] == user)
        {
            for(int j = 0;j<m_Model->rowCount();++j)   //改变视图
            {
                if(m_Model->data(m_Model->index(j,2)).toInt() == user.m_seatId)
                {
                    m_Model->removeRow(j);
                }
            }
            ser.seat.remove(i);
            emit serviceinfo_mainwindow(ser);
            return;
        }
    }
    QMessageBox::critical(this,"退票失败","只有座位本人才能退订！");
}


void serviceInfo::on_deleteService_clicked()
{
    if(priority == 1)
    {
        emit serviceinfo_mainwindow(ser,true);
        this->~serviceInfo();
    }
    else
    {
        QMessageBox::critical(this,"权限不足","您无权删除班次！");
    }
}


void serviceInfo::on_save_clicked()  //保存管理员修改后的乘客数据
{
    for(int i = 0;i<m_Model->rowCount();++i)
    {
        passenger temp;
        temp.m_name = m_Model->data(m_Model->index(i,0)).toString();
        temp.m_id = m_Model->data(m_Model->index(i,1)).toString();
        temp.m_seatId = m_Model->data(m_Model->index(i,2)).toInt();
        ser.seat[i] = temp;
    }
    emit serviceinfo_mainwindow(ser);
    this->close();
}

