///////////////////////////////////////////////////
//时间：2022.8.20
//创作者：09021102郭天琦
//用途：展示所有班次信息，可搜索筛选班次，提供各种服务的主菜单
///////////////////////////////////////////////////

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <QHeaderView>
#include <QSortFilterProxyModel>
#include <service.h>
#include <serviceinfo.h>
#include <addservice.h>
#include <login.h>
#include <QMessageBox>
#include <QDebug>
#include <QFileDialog>
#include <filechoose.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

signals:
    void mainwindow_serviceinfo(Service,passenger,int);

private slots:

    void on_findEdit_textChanged(const QString &arg1);

    void on_comboBox_currentIndexChanged(int index);

    void on_actionadd_triggered();

    void process_addservice_mainwindow(Service);

    void slot_doubleClicked(const QModelIndex&);//登录后打开特定班次信息的槽函数

    void on_actionread_triggered();

    void on_actionwrite_triggered();

public slots:
    void process_login_mainwindow(passenger);
    void process_serviceinfo_mainwindow(Service,bool = false);
    void process_filechoose_mainwindow(QString);

private:
    Ui::MainWindow     *ui;

    QVector<Service> infoTable;
    int selectedService;         //判断被查看的班次
    int priority;               //判断权限
    passenger user;       //存储login传来的用户信息
    QStandardItemModel  *m_Model;      //数据模型对象指针
    QSortFilterProxyModel *m_FilterModel;  //过滤器模型对象指针

};

#endif // MainWindow_H
