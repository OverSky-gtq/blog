#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("班次信息表");
    ui->findEdit->setPlaceholderText("请输入查找内容（自动查找）");

    m_Model = new QStandardItemModel(ui->tableView);
    m_Model->setHorizontalHeaderLabels(QStringList() << "班次号" << "终点城市"<< "发车时间" << "票价" <<"售票情况" <<"备注");
        //建立过滤器模型对象空间并指定父对象
    m_FilterModel = new QSortFilterProxyModel(ui->tableView);
        //指定过滤器模型的数据源模型
    m_FilterModel->setSourceModel(m_Model);
        //指定初始化过滤列
    m_FilterModel->setFilterKeyColumn(0);
        // 将过滤器模型设置到表对象上
    ui->tableView->setModel(m_FilterModel);

    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows); //只能选取单行
    ui->tableView->setColumnWidth(2,140);//调整发车时间列视图宽度，以便完整显示
    connect(ui->tableView, SIGNAL(doubleClicked(const QModelIndex &)), this, SLOT(slot_doubleClicked(const QModelIndex &)));

    selectedService = -1;  //没有选择特定班次时默认为-1
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::slot_doubleClicked(const QModelIndex &index) //双击特定班次后发送班次对象和身份并展示serviceInfo窗口
{
    serviceInfo *info = new serviceInfo;
    connect(this,SIGNAL(mainwindow_serviceinfo(Service,passenger,int)),info,SLOT(process_mainwindow_serviceinfo(Service,passenger,int)));
    connect(info,SIGNAL(serviceinfo_mainwindow(Service,bool)),this,SLOT(process_serviceinfo_mainwindow(Service,bool)));//主窗口可以接收被改变的班次座位表
    if(priority == 1)
    {
        QModelIndex newindex = m_FilterModel->mapToSource(index);   //防止用户的搜索行为导致索引错误
        selectedService = newindex.row(); //记录被选中的班次索引
    }
    else     //防止因时间过滤导致的索引错误
    {
        QString serviceId = m_Model->data(m_Model->index(index.row(),0)).toString();
        QDateTime startTime = m_Model->data(m_Model->index(index.row(),2)).toDateTime();
        //获取被双击的班次信息

        for(int i = 0;i<infoTable.size();++i)  //查找被双击班次，获得原索引
        {
            if(infoTable[i].m_serviceId == serviceId && infoTable[i].m_startTime == startTime)
            {
                    selectedService = i;  //记录被选中的班次索引
                    break;
            }
        }
    }
    emit mainwindow_serviceinfo(infoTable[selectedService],user,priority);
    info->show();

}

void MainWindow::process_login_mainwindow(passenger data) //接收login传来的身份信息并存储
{
    user = data;
    if(data.m_seatId == 1)
        priority = 1;
    else
        priority = 0;
    QFile File("data.txt");
    File.open(QIODevice::ReadWrite);
    QTextStream stream(&File);
    if(priority == 1)  //根据权限决定是否显示全部班次和是否可编辑，旅客只能看到今明后三天的班次
    {
        while(!stream.atEnd())
        {
            Service temp;
            temp.read(stream);
            infoTable.push_back(temp);
            m_Model->appendRow(QList<QStandardItem *>()
                                   <<new QStandardItem(temp.m_serviceId)
                                   <<new QStandardItem(temp.m_destination)
                                   <<new QStandardItem(temp.m_startTime.toString("yyyy-MM-dd hh:mm"))
                                   <<new QStandardItem(QString::number(temp.m_price))
                                   <<new QStandardItem(QString::number(temp.getLeftTicket())+'/'+QString::number(temp.m_numOfTicket))
                                   <<new QStandardItem(temp.m_comment));

        }
    }
    else
    {
            while(!stream.atEnd())
            {
                Service temp;
                temp.read(stream);
                infoTable.push_back(temp);
                QDate cur = QDate::currentDate();
                QDate other = temp.m_startTime.date();
                if(cur.daysTo(other) < 3 && cur.daysTo(other)>0)
                {
                    m_Model->appendRow(QList<QStandardItem *>()
                                       <<new QStandardItem(temp.m_serviceId)
                                       <<new QStandardItem(temp.m_destination)
                                       <<new QStandardItem(temp.m_startTime.toString("yyyy-MM-dd hh:mm"))
                                       <<new QStandardItem(QString::number(temp.m_price))
                                       <<new QStandardItem(QString::number(temp.getLeftTicket())+'/'+QString::number(temp.m_numOfTicket))
                                       <<new QStandardItem(temp.m_comment));
                }
            }
            ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);//旅客不可编辑
    }
}

void MainWindow::process_serviceinfo_mainwindow(Service data,bool isdelete)
{
    if(isdelete)//判断serviceinfo窗口被触发的按键
    {
        infoTable.remove(selectedService);
        m_Model->removeRow(selectedService);
    }
    else
    {
        infoTable[selectedService] = data;
        if(priority == 1)
            m_Model->setItem(selectedService,4,new QStandardItem(QString::number(data.getLeftTicket())+'/'+QString::number(data.m_numOfTicket)));
        else //防止因时间过滤引起的索引错误
        {
            for(int i = 0;i<m_Model->rowCount();++i)
            {
                QString serviceId = m_Model->data(m_Model->index(i,0)).toString();
                QDateTime startTime = m_Model->data(m_Model->index(i,2)).toDateTime();
                if(serviceId == data.m_serviceId && startTime == data.m_startTime)
                {
                    m_Model->setItem(i,4,new QStandardItem(QString::number(data.getLeftTicket())+'/'+QString::number(data.m_numOfTicket)));
                }
            }
        }
        //更新视图中的余票
    }
    ui->tableView->repaint();   //刷新视图
}

void MainWindow::process_filechoose_mainwindow(QString path) //接收选择的路径并进行读取
{
    m_Model->clear();
    m_Model->setHorizontalHeaderLabels(QStringList() << "班次号" << "终点城市"<< "发车时间" << "票价" <<"售票情况" <<"备注");
    ui->tableView->setColumnWidth(2,140);//调整发车时间列视图宽度，以便完整显示
    QFile File(path);
    File.open(QIODevice::ReadWrite);
    QTextStream stream(&File);
    //一直读取直到文件读完先写入temp再将之放入容器
    while(!stream.atEnd())
    {
        Service temp;
        temp.read(stream);
        infoTable.push_back(temp);
        m_Model->appendRow(QList<QStandardItem *>()
                               <<new QStandardItem(temp.m_serviceId)
                               <<new QStandardItem(temp.m_destination)
                               <<new QStandardItem(temp.m_startTime.toString("yyyy-MM-dd hh:mm"))
                               <<new QStandardItem(QString::number(temp.m_price))
                               <<new QStandardItem(QString::number(temp.getLeftTicket())+'/'+QString::number(temp.m_numOfTicket))
                               <<new QStandardItem(temp.m_comment));

    }

}

void MainWindow::on_findEdit_textChanged(const QString &arg1)
{
    m_FilterModel->setFilterRegExp(arg1);  //传入查询的正则表达式
}


void MainWindow::on_comboBox_currentIndexChanged(int index)  //更改查询项目
{
    m_FilterModel->setFilterKeyColumn(index);
}

void MainWindow::on_actionadd_triggered()   //新建班次
{
    if(priority == 1)
    {
    addService *serviceAdd = new addService;
    serviceAdd->show();
    connect(serviceAdd,SIGNAL(addservice_mainwindow(Service)),this,SLOT(process_addservice_mainwindow(Service)));
    }
    else
    {
        QMessageBox::critical(this,"权限不足","新建班次需要提供管理员权限！");
    }
}
void MainWindow::process_addservice_mainwindow(Service temp)  //接收addService窗口的新班次对象并存储
{
     infoTable.push_back(temp);
     m_Model->appendRow(QList<QStandardItem *>()
                        <<new QStandardItem(temp.m_serviceId)
                        <<new QStandardItem(temp.m_destination)
                        <<new QStandardItem(temp.m_startTime.toString("yyyy-MM-dd hh:mm"))
                        <<new QStandardItem(QString::number(temp.m_price))
                        <<new QStandardItem(QString::number(temp.getLeftTicket())+'/'+QString::number(temp.m_numOfTicket))
                        <<new QStandardItem(temp.m_comment));

}


void MainWindow::on_actionread_triggered()
{
    if(priority == 1)
    {
        filechoose *choosefile=new filechoose;
        //接收选择文件的路径
        connect(choosefile,SIGNAL(sendpath(QString)),this,SLOT(process_filechoose_mainwindow(QString)));
        choosefile->show();
    }
    else
    {
        QMessageBox::critical(this,"权限不足","管理班次需要提供管理员权限！");
    }
}

void MainWindow::on_actionwrite_triggered()
{
        QFile file("data.txt");
        if(! file.open(QIODevice::WriteOnly|QIODevice::Text))
        {
            return;
        }
        for(int j = 0;j<infoTable.size();++j) //若视图与原数据不一致，则优先保存视图上的数据
        {
            bool isSave = false;
            for(int i = 0;i<m_Model->rowCount();++i)
            {
                Service temp;
                temp.m_serviceId = m_Model->data(m_Model->index(i,0)).toString();
                temp.m_destination = m_Model->data(m_Model->index(i,1)).toString();
                temp.m_startTime = m_Model->data(m_Model->index(i,2)).toDateTime();
                temp.m_price = m_Model->data(m_Model->index(i,3)).toInt();

                QString ticketSale = m_Model->data(m_Model->index(i,4)).toString();
                int width = ticketSale.length() - ticketSale.lastIndexOf('/') - 1;
                temp.m_numOfTicket = ticketSale.right(width).toInt();    //从"余票/总票" 中截取出余票

                temp.m_comment = m_Model->data(m_Model->index(i,5)).toString();
                //从视图上获取最新数据并存入temp，然后调用save函数
                QTextStream stream(&file);

                if(infoTable[j] == temp)
                {
                    temp.seat = infoTable[j].seat;
                    temp.save(stream);
                    isSave = true;
                }
                if(i == m_Model->rowCount()-1 && isSave == false) //最后一次对比若还未保存说明视图上无此班次，直接存入原数据
                {
                    infoTable[j].save(stream);
                }
            }

        }
        QMessageBox::information(this,"提示","保存成功！");
}
