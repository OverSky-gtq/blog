////////////////////////////////////////////////////////////////////
//时间：2022.8.20
//创作者：09021102郭天琦
//用途：班次类，包含班次号、目的城市、发车时间、票价、售票情况、班次备注、乘客集
///////////////////////////////////////////////////////////////////

#ifndef SERVICE_H
#define SERVICE_H
#include <QString>
#include <QDateTime>
#include <QVector>
#include <QDebug>
#include <passenger.h>
class Service
{
public:
    Service();
    bool operator==(const Service&);
    int getLeftTicket();   //获取剩余票数
    void addPassenger(passenger);
    void delPassenger(passenger);
    void save(QTextStream&);
    void read(QTextStream&);

    QString m_serviceId;
    QString m_destination;
    QDateTime m_startTime;
    QString m_comment;
    int m_price;
    int m_numOfTicket;
    QVector<passenger> seat;
};

#endif // SERVICE_H
