#ifndef SERVICEINFOTABLE_H
#define SERVICEINFOTABLE_H
#include <QVector>
#include <service.h>

class ServiceInfoTable
{
public:
    ServiceInfoTable();
protected:
    QVector<Service> infoTable;

};

#endif // SERVICEINFOTABLE_H
