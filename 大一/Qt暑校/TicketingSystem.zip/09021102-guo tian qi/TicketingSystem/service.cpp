#include "service.h"

Service::Service()
{//初始化
    m_serviceId = "暂无";
    m_destination = "暂无";
    QDateTime m_startTime = QDateTime::currentDateTime();
    m_price = 0;
    m_numOfTicket = 0;
}

bool Service::operator==(const Service &data)
{
    if(m_serviceId==data.m_serviceId && m_startTime==data.m_startTime)
        return true;
    else
        return false;
}

int Service::getLeftTicket()
{
    return m_numOfTicket - seat.size();
}

void Service::addPassenger(passenger data)
{
    bool isRepeat = false;
    for(int i = 0;i<m_numOfTicket;++i)
    {
        if(seat[i].m_seatId == data.m_seatId)
        {
            if(seat[i].m_seatId != -1)
            {
                isRepeat = true;
            }
            break;
        }
    }
    if(!isRepeat)
    {
        seat.push_back(data);
        m_numOfTicket++;
    }
    else
    {
        qDebug()<<"此座位已有人"<<endl;
    }

}

void Service::delPassenger(passenger data)
{
    for(int i = 0;i<m_numOfTicket;++i)
    {
        if(seat[i] == data)
        {
            seat.removeAt(i);
            m_numOfTicket--;
            break;
        }
    }
}

void Service::save(QTextStream& out)
{
    out<<m_serviceId<<endl;
    out<<m_destination<<endl;
    out<<m_startTime.toString("yyyy-MM-dd hh:mm")<<endl;
    out<<m_comment<<endl;
    out<<m_price<<endl;
    out<<m_numOfTicket<<endl;
    out<<seat.size()<<endl;     //将size一起存入，便于读取不确定大小的service类
    for(int i = 0;i<seat.size();++i)
    {
        seat[i].save(out);
    }
}
void Service::read(QTextStream& in)
{
    m_serviceId = in.readLine();
    m_destination = in.readLine();
    m_startTime = QDateTime::fromString(in.readLine(),"yyyy-MM-dd hh:mm");
    m_comment = in.readLine();
    m_price = in.readLine().toInt();
    m_numOfTicket = in.readLine().toInt();
    int size = in.readLine().toInt();
    for(int i = 0;i<size;++i)
    {
        passenger temp;
        temp.read(in);
        seat.push_back(temp);
    }
}
