////////////////////////////////////////////////////////////////////////
//时间：2022.8.20
//创作者：09021102郭天琦
//用途：被双击查看的特定班次信息，可进行购票，退票。管理员可以更改乘客信息以及删除班次
////////////////////////////////////////////////////////////////////////


#ifndef SERVICEINFO_H
#define SERVICEINFO_H

#include <QWidget>
#include <service.h>
#include <mainwindow.h>
#include <QMessageBox>
#include <QStandardItemModel>
#include <QSortFilterProxyModel>

namespace Ui {
class serviceInfo;
}

class serviceInfo : public QWidget
{
    Q_OBJECT

public:
    explicit serviceInfo(QWidget *parent = nullptr);
    ~serviceInfo();

protected:
    Service ser;
    passenger user;
    int priority;
    QStandardItemModel  *m_Model;
    QSortFilterProxyModel *m_FilterModel;
signals:
    void serviceinfo_mainwindow(Service,bool = false);
public slots:
    void process_mainwindow_serviceinfo(Service,passenger,int); //接收被双击的班次对象和身份信息


private slots:
    void on_buyTicket_clicked();

    void on_returnTicket_clicked();

    void on_deleteService_clicked();

    void on_save_clicked();

private:
    Ui::serviceInfo *ui;
};

#endif // SERVICEINFO_H
