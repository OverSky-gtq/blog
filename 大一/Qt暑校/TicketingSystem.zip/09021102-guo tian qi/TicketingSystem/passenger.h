/////////////////////////////////////////////
//时间：2022.8.20
//创作者：09021102郭天琦
//用途：乘客类，包含姓名、身份证、座位号
////////////////////////////////////////////

#ifndef PASSENGER_H
#define PASSENGER_H
#include <QString>
#include <QFile>
#include <QTextStream>
class passenger
{
public:
    passenger();
    QString m_name;
    QString m_id;
    int m_seatId;
    void save(QTextStream&);
    void read(QTextStream&);
    bool operator==(const passenger&);
};

#endif // PASSENGER_H
