#include "serviceinfotable.h"

ServiceInfoTable::ServiceInfoTable()
{

}
