#include "passenger.h"

passenger::passenger()
{
    m_name = "暂无";
    m_id = "暂无";
    m_seatId = -1;
}

bool passenger::operator==(const passenger &data)
{
    if(this->m_id==data.m_id && this->m_name==data.m_name && this->m_seatId==data.m_seatId)
        return true;
    else
    {
        return false;
    }
}

void passenger::save(QTextStream& out)
{
    out<<m_name<<endl;
    out<<m_id<<endl;
    out<<m_seatId<<endl;
}

void passenger::read(QTextStream& in)
{
    m_name = in.readLine();
    m_id = in.readLine();
    m_seatId = in.readLine().toInt();
}

