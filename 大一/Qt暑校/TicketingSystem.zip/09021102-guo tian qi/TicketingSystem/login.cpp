#include "login.h"
#include "ui_login.h"

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    ui->password->setPlaceholderText("验证管理员权限,默认admin");
    ui->password->setEchoMode(QLineEdit::Password);
}

login::~login()
{
    delete ui;
}


void login::on_cancel_clicked()
{
    this->close();
}

void login::on_ok_clicked()   //确认身份信息，进入主窗口
{
    tempPassenger.m_name = ui->name->text();
    tempPassenger.m_id = ui->id->text();
    if(ui->password->text() == "admin")
        tempPassenger.m_seatId = 1;
    else
        tempPassenger.m_seatId = 0;   //记录身份信息,未被使用的seatId暂时用来储存权限

    MainWindow *serviceTable = new MainWindow;
    connect(this,SIGNAL(login_mainwindow(passenger)),serviceTable,SLOT(process_login_mainwindow(passenger)));
    emit login_mainwindow(tempPassenger);    //发送身份信息给班次主窗口，然后析构
    serviceTable->show();
    this->~login();
}


void login::on_passwordModel_clicked()  //密钥是否可见
{
    if(login_int_counterpasswordmodel%2==1)
    {
        ui->password->setEchoMode(QLineEdit::Normal);
    }
    else
    {
        ui->password->setEchoMode(QLineEdit::Password);
    }
    login_int_counterpasswordmodel++;
}

