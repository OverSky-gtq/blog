/////////////////////////////////////////////
//时间：2022.8.20
//创作者：09021102郭天琦
//用途：文件读取时用来选择文件的窗口
////////////////////////////////////////////

#ifndef FILECHOOSE_H
#define FILECHOOSE_H

#include <QWidget>
#include "QFileDialog"

namespace Ui {
class filechoose;
}

class filechoose : public QWidget
{
    Q_OBJECT

public:
    explicit filechoose(QWidget *parent = nullptr);
    ~filechoose();
    QString path;//用于储存选择文件的路径

private slots:
    void on_cancel_clicked();//点击"取消"关闭窗口

    void on_pushButton_clicked();//选择文件

    void on_confirm_clicked();//点击“确认”读取文件

signals:
    void sendpath(QString);//path信号，传输选择文件的路径
private:
    Ui::filechoose *ui;
};

#endif // FILECHOOSE_H
