/////////////////////////////////////////////
//时间：2022.8.20
//创作者：09021102郭天琦
//用途：新增班次的输入窗口
////////////////////////////////////////////

#ifndef ADDSERVICE_H
#define ADDSERVICE_H

#include <QWidget>
#include <service.h>

namespace Ui {
class addService;
}

class addService : public QWidget
{
    Q_OBJECT

public:
    explicit addService(QWidget *parent = nullptr);
    ~addService();
signals:
    void addservice_mainwindow(Service);  //发送新的Service对象

private slots:
    void on_cancel_clicked();//点击"取消"关闭窗口

    void on_Save_clicked();//点击"保存"对输入班次进行保存

private:
    Ui::addService *ui;
};

#endif // ADDSERVICE_H
