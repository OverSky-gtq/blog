#include "filechoose.h"
#include "ui_filechoose.h"

filechoose::filechoose(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::filechoose)
{
    ui->setupUi(this);
}

filechoose::~filechoose()
{
    delete ui;
}

//点击“取消”关闭窗口
void filechoose::on_cancel_clicked()
{
     this->close();
     this->~filechoose();
}


//文件读取操作
void filechoose::on_pushButton_clicked()
{
    //将选择文件的路径赋值path
    path = QFileDialog::getOpenFileName(this,"打开文件","data.txt","(*.txt)") ;
    ui->lineEdit->setText(path);  //在LineEdit显示路径
}



//点击确认后发送选择的文件路径
void filechoose::on_confirm_clicked()
{
    //发送信号路径path
    emit sendpath(path);
    this->close();
    this->~filechoose();//析构
}
