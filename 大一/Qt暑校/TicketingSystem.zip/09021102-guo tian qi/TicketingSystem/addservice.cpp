#include "addservice.h"
#include "ui_addservice.h"

addService::addService(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addService)
{
    ui->setupUi(this);
    ui->dateTimeEdit->setCalendarPopup(true);//显示日历
    ui->dateTimeEdit->setDateTime(QDateTime::currentDateTime());
}

addService::~addService()
{
    delete ui;
}

void addService::on_Save_clicked()
{
    Service temp;
    temp.m_startTime = ui->dateTimeEdit->dateTime();
    temp.m_serviceId = ui->addServiceId->text();
    temp.m_comment = ui->addComment->text();
    temp.m_destination = ui->addDestination->text();
    temp.m_numOfTicket = ui->addNumOfTicket->text().toInt();
    temp.m_price = ui->addPrice->text().toInt();

    emit addservice_mainwindow(temp);
    this->close();
}

void addService::on_cancel_clicked()
{
    this->~addService();
}
