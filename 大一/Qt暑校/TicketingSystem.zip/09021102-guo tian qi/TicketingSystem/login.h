/////////////////////////////////////////////
//时间：2022.8.20
//创作者：09021102郭天琦
//用途：录入身份信息，区分管理员和旅客
////////////////////////////////////////////

#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include <service.h>
#include <mainwindow.h>

namespace Ui {
class login;
}

class login : public QWidget
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();
protected:
    passenger tempPassenger;
    int login_int_counterpasswordmodel;
signals:
    void login_mainwindow(passenger);

private slots:
    void on_cancel_clicked();

    void on_ok_clicked();

    void on_passwordModel_clicked();

private:
    Ui::login *ui;
};

#endif // LOGIN_H
