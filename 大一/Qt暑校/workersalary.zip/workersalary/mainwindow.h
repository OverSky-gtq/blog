////////////////////
///主窗口
//时间：2021 7、21
//创作者：王景祺
///用途：进行职工信息的管理
/// ///////////////////






#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "addworker.h"
#include "worker.h"
#include "QVector"

#include <QMainWindow>

QT_BEGIN_NAMESPACE







namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow//主窗口
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    worker worker_main_temp;//用于储存当前编辑的临时员工信息
    QVector<worker> main_Vector_worker;//Vector容器储存当前输入的所有员工
    int main_int_CountWorker=0;//储存员工数

signals:
    void sendworker(worker);//worker信号

private slots:

    void on_Add_triggered();//"新增"打开窗口

    void on_Load_triggered();//读入文件

    void process_addworker(worker);//发送worker类信号

    void mainwindow_proess_workersalary(int,int);//实现信号与信号的对接

    void process_changeworker(worker,int);//修改职工信息槽函数

    void process_deleteworker(int);//删除职工槽函数

    void on_Save_triggered();//保存文件槽函数

    void process_loadoperation(QString);//读取文件槽函数

    void on_actioninfo_triggered();//打开使用说明窗口

    void on_actionexit_triggered();//退出登录


private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
