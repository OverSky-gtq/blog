/////////////////////////////////////////////
//选择文件
//时间：2021 7、21
//创作者：王景祺
//用途：选择文件窗口
////////////////////////////////////////////

#ifndef FILCHOOSE_H
#define FILCHOOSE_H

#include <QWidget>

namespace Ui {
class FilChoose;
}

class FilChoose : public QWidget//选择文件窗口
{
    Q_OBJECT

public:
    explicit FilChoose(QWidget *parent = nullptr);
    ~FilChoose();
    QString path;//用于储存选择文件的路径

private slots:
    void on_cancel_clicked();//点击"取消"关闭窗口

    void on_pushButton_clicked();//选择文件

    void on_confirm_clicked();//点击“确认”读取文件

signals:
    void sendpath(QString);//path信号，传输选择文件的路径


private:
    Ui::FilChoose *ui;
};

#endif // FILCHOOSE_H
