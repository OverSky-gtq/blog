//////////////////////////////
///职工详细信息显示
//时间：2021 7、21
//创作者：王景祺
/// 用途：可对职工的姓名，工号，电话，住址进行相关展示
/// /////////////////////////




#ifndef WORKERSALARY_H
#define WORKERSALARY_H
#include "worker.h"

#include <QWidget>

namespace Ui {
class workersalary;//职工工资及详细信息显示窗口
}

class workersalary : public QWidget
{
    Q_OBJECT

public:
    explicit workersalary(QWidget *parent = nullptr);
    ~workersalary();
    int row_salary=0;//用于存储用户点击的是第几个员工
    worker salary_worker_temp;//存储修改后的员工信息
signals:
    void sendData_2(worker,int);//worker与row信号

    void sendDate_row(int);//row信号

    void sendworkerforchange(worker);//用于修改基本信息的worker信号

private slots:
    void open(int,int);//打开工资信息窗口槽函数

    void widget_process_worker(worker);//传入worker对象槽函数

    void on_Basicchange_clicked();//点击"修改基本信息"打开窗口槽函数

    void process_changeworker_s(worker);//对workersalary的职工基本信息进行改变槽函数

    void process_changesalary_s(Salary);//对职工的月工资信息进行改变并发送信号改变主窗口的月工资信息槽函数

    void on_Salarychange_clicked();//打开修改月工资修改窗口槽函数

    void on_delete_2_clicked();//删除员工槽函数

    void on_salaryinfo_clicked();//打开员工实发数窗口

    void on_loadpicture_clicked();

private:
    Ui::workersalary *ui;
};

#endif // WORKERSALARY_H
