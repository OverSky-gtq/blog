///////////////////
//注册窗口.h
//时间：2021 7、21
//创作者：王景祺
//进行用户名注册
///////////////////




#ifndef REG_H
#define REG_H

#include <QWidget>

namespace Ui {
class reg;
}

class reg : public QWidget//注册窗口
{
    Q_OBJECT

public:
    explicit reg(QWidget *parent = nullptr);
    ~reg();

private slots:
    void on_reg_2_clicked();//点击注册将注册的账号密码写入文件


    void on_pushButton_2_clicked();//点击取消关闭窗口

private:
    Ui::reg *ui;
};

#endif // REG_H
