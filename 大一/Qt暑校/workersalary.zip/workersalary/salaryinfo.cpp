///////////////////////////////
//显示月工资信息窗口
//时间：2021 7、21
//创作者：王景祺
//用途：进行月工资信息的展示,基本工资等
/////////////////////////////////


#include "salaryinfo.h"
#include "ui_salaryinfo.h"
#include "QDebug"

salaryinfo::salaryinfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::salaryinfo)
{
    ui->setupUi(this);
    //制表头
    this->ui->salarytable_2->setColumnCount(12);
    this->ui->salarytable_2->setRowCount(3);
    this->ui->salarytable_2->setHorizontalHeaderLabels(QStringList()<<"一月"<<"二月"<<"三月"<<"四月"<<"五月"<<"六月"<<"七月"<<"八月"<<"九月"<<"十月"<<"十一月"<<"十二月");
    this->ui->salarytable_2->setVerticalHeaderLabels(QStringList()<<"税前总工资"<<"个人所得税"<<"实发数");
}

salaryinfo::~salaryinfo()
{
    qDebug()<<"salaryinfo析构";
    delete ui;
}

//点击关闭窗口
void salaryinfo::on_close_clicked()
{
    this->close();
    this->~salaryinfo();
}

//计算实发数并进行显示 w用于储存需要显示实发数的员工的工资信息
void salaryinfo::process_salaryInfo(worker w)
{
    double salaryinfo_double_beforetotal[12],salary_double_tax[12]={0,0,0,0,0,0,0,0,0,0,0,0},salary_double_prac[12];



    //将Qstring类的工资转为int型
    for(int n=0;n<OneYear;n++)
    {
         salaryinfo_double_beforetotal[n]=w.salary.m_Qs_basicsalary[n].toDouble()+w.salary.m_Qs_jobssalary[n].toDouble()+w.salary.m_Qs_Dutytostick[n].toDouble()+w.salary.m_Qs_Trafficsubsidies[n].toDouble()+w.salary.m_Qs_agesalary[n].toDouble()+w.salary.m_Qs_allowance[n].toDouble()+w.salary.m_Qs_housing[n].toDouble();
    }
    for(int n=0;n<OneYear;n++)
    {
        QString s_t;
        s_t = QString::number(salaryinfo_double_beforetotal[n]);
        this->ui->salarytable_2->setItem(0,n,new QTableWidgetItem(s_t));
    }



    //计算个人所得税
    for(int n=0;n<OneYear;n++)
    {
        if(salaryinfo_double_beforetotal[n]>800&&salaryinfo_double_beforetotal[n]<1000)
        {
            salary_double_tax[n]+=(salaryinfo_double_beforetotal[n]-800)*0.05;
        }
        else if(salaryinfo_double_beforetotal[n]>=1000&&salaryinfo_double_beforetotal[n]<5000)
        {
            salary_double_tax[n]+=20;
            salary_double_tax[n]+=(salaryinfo_double_beforetotal[n]-1000)*0.1;
        }
        else if(salaryinfo_double_beforetotal[n]>=5000)
        {
            salary_double_tax[n]+=420;
            salary_double_tax[n]+=(salaryinfo_double_beforetotal[n]-5000)*0.2;
        }
        for(int n=0;n<OneYear;n++)
        {
            QString s_t;
            s_t = QString::number(salary_double_tax[n]);
            this->ui->salarytable_2->setItem(1,n,new QTableWidgetItem(s_t));
        }
        for(int n=0;n<OneYear;n++)
        {
            salary_double_prac[n]=salaryinfo_double_beforetotal[n]-salary_double_tax[n];
        }
        for(int n=0;n<OneYear;n++)
        {
            QString s_t;
            s_t = QString::number(salary_double_prac[n]);
            this->ui->salarytable_2->setItem(2,n,new QTableWidgetItem(s_t));
        }
    }
}
