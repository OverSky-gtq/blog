///////////////////////
//登录窗口
//时间：2021 7、21
//创作者：王景祺
//用途：进行登录处理
//////////////////////



#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>

namespace Ui {
class login;
}

class login : public QWidget//登陆界面窗口
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    int login_int_counterpasswordmodel=0;//用于切换密码显示模式的参数
    ~login();

private slots:
    void on_login_2_clicked();//点击登录进行账号密码匹对

    void on_register_2_clicked();//点击注册打开注册窗口

    void on_pushButton_clicked();//显示密码

private:
    Ui::login *ui;
};

#endif // LOGIN_H
