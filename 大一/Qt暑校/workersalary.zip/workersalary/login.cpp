///////////////////////
//登录窗口
//时间：2021 7、21
//创作者：王景祺
//用途：进行登录处理
//////////////////////

#include "login.h"
#include "ui_login.h"
#include "mainwindow.h"
#include "QFile"
#include "QString"
#include "QMessageBox"
#include "QTextStream"
#include "reg.h"
#include "QDebug"
#include "QIcon"

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    //显示密码的图标
    QIcon eye(":Image/eye.png");
    ui->pushButton->setIcon(eye);
}

login::~login()
{
    delete ui;
}


//点击登录检索用户名账号文件判断是否有账户
void login::on_login_2_clicked()
{
    //打开文件
    QFile File("C:\\Users\\wangj\\Documents\\workersalary\\account\\accountandpassword.txt");
    File.open(QIODevice::ReadOnly);
    while(!File.atEnd())
    {
        QString read_line=File.readLine();
        read_line=read_line.left(read_line.length()-1);//读取到的账号末尾会有/n删除
        //如果文件读取完还没有匹配账户显示用户名或密码错误

        //如果用户名匹配再匹配密码
        if(ui->accont->displayText()==read_line)
        {
            read_line=File.readLine();
            read_line=read_line.left(read_line.length()-1);//读取到的密码末尾会有/n删除
            if(ui->passwordinput->text()==read_line)
            {


                //账号密码匹对成功打开主窗口
                MainWindow* w=new MainWindow;
                w->show();
                this->close();
                break;
            }
            else
            {
                QMessageBox::critical(this,"密码或用户名错误","密码或用户名错误");
                break;
            }
        }


        //读取奇数行的用户名
        else
        {
        read_line=File.readLine();
        }


        //读到最后无配对账号密码显示用户名或密码错误
        if(File.atEnd()==true)
        {
            QMessageBox::critical(this,"密码或用户名错误","密码或用户名错误");
            break;
        }
    }
}



//打开注册窗口
void login::on_register_2_clicked()
{
    reg* REG=new reg;
    REG->show();
}



//通过点击按钮更改login_int_counterpasswordmodel的奇偶性改变密码显示模式
void login::on_pushButton_clicked()
{
    if(login_int_counterpasswordmodel%2==0)
    {
        ui->passwordinput->setEchoMode(QLineEdit::Normal);
    }
    else
    {
        ui->passwordinput->setEchoMode(QLineEdit::Password);
    }
    login_int_counterpasswordmodel++;
}
