/////////////////////////////////////////////
//更改员工月工资窗口
//时间：2021 7、21
//创作者：王景祺
//用途：更改员工月工资窗口
////////////////////////////////////////////

#include "changeworkersalary.h"
#include "ui_changeworkersalary.h"
#include "QDebug"


changeworkersalary::changeworkersalary(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::changeworkersalary)
{
    ui->setupUi(this);



    //制表头
    this->ui->salrytable->setColumnCount(7);
    this->ui->salrytable->setRowCount(12);
    this->ui->salrytable->setVerticalHeaderLabels(QStringList()<<"一月"<<"二月"<<"三月"<<"四月"<<"五月"<<"六月"<<"七月"<<"八月"<<"九月"<<"十月"<<"十一月"<<"十二月");
    this->ui->salrytable->setHorizontalHeaderLabels(QStringList()<<"基本工资"<<"岗位工资"<<"工龄工资"<<"津贴"<<"补贴"<<"房贴"<<"交通补贴");
}

changeworkersalary::~changeworkersalary()
{
    qDebug()<<"changesalary析构";
    delete ui;
}




//点击取消关闭窗口
void changeworkersalary::on_cancel_clicked()
{
    this->close();
    this->~changeworkersalary();//析构
}




//接收workersaslary窗口传入的worker对象w,与用户选择的第几个职工row
void changeworkersalary::changeworkersalaryimple(worker w, int row)
{



    //表格显示原来工资信息
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,0,new QTableWidgetItem(w.salary.m_Qs_basicsalary[n])); //基本工资
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,1,new QTableWidgetItem(w.salary.m_Qs_jobssalary[n]));//岗位工资
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,2,new QTableWidgetItem(w.salary.m_Qs_agesalary[n]));//工龄工资
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,3,new QTableWidgetItem(w.salary.m_Qs_allowance[n]));//津贴
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,4,new QTableWidgetItem(w.salary.m_Qs_Dutytostick[n]));//补贴
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,5,new QTableWidgetItem(w.salary.m_Qs_housing[n]));//房贴
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,6,new QTableWidgetItem(w.salary.m_Qs_Trafficsubsidies[n]));//交通补贴
    }
}





//点击保存后获取表格的信息放入change_salary再将之作为信号发送
void changeworkersalary::on_save_clicked()
{
    for(int n=0;n<12;n++)
    {
        change_salary.m_Qs_basicsalary[n]=ui->salrytable->item(n,0)->text();//基本工资
    }
    for(int n=0;n<12;n++)
    {
        change_salary.m_Qs_jobssalary[n]=ui->salrytable->item(n,1)->text();//岗位工资
    }
    for(int n=0;n<12;n++)
    {
        change_salary.m_Qs_agesalary[n]=ui->salrytable->item(n,2)->text();//津贴
    }
    for(int n=0;n<12;n++)
    {
        change_salary.m_Qs_allowance[n]=ui->salrytable->item(n,3)->text();//补贴
    }
    for(int n=0;n<12;n++)
    {
        change_salary.m_Qs_Dutytostick[n]=ui->salrytable->item(n,4)->text();//房贴
    }
    for(int n=0;n<12;n++)
    {
        change_salary.m_Qs_housing[n]=ui->salrytable->item(n,5)->text();//交通补贴
    }for(int n=0;n<12;n++)
    {
        change_salary.m_Qs_Trafficsubsidies[n]=ui->salrytable->item(n,6)->text();//交通补贴
    }
    emit sendsalary(change_salary);
    this->close();
}
