/////////////////////////////////////////////
//选择文件
//时间：2021 7、21
//创作者：王景祺
//用途：选择文件窗口
///////////////////////////////////////////

#include "filchoose.h"
#include "ui_filchoose.h"
#include "QFileDialog"
#include "QDebug"

FilChoose::FilChoose(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FilChoose)
{
    ui->setupUi(this);
}

FilChoose::~FilChoose()
{
    qDebug()<<"Filechoose析构";
    delete ui;
}


//点击“取消”关闭窗口
void FilChoose::on_cancel_clicked()
{
     this->close();
    this->~FilChoose();
}


//文件读取操作
void FilChoose::on_pushButton_clicked()
{


    //将选择文件的路径赋值path
    path = QFileDialog::getOpenFileName(this,"打开文件","C:\\Users\\wangj\\Documents\\workersalary","(*.txt)") ;
    ui->lineEdit->setText(path);//在lineedit显示路径
}



//点击确认后发送选择的文件路径
void FilChoose::on_confirm_clicked()
{


    //发送信号路径path
    emit sendpath(path);
    this->close();
    this->~FilChoose();//析构
}
