///////////////////////////////
//显示月工资信息窗口
//时间：2021 7、21
//创作者：王景祺
//用途：进行月工资信息的展示,基本工资等
/////////////////////////////////




#ifndef SALARYINFO_H
#define SALARYINFO_H
#include "worker.h"


#include <QWidget>

namespace Ui {
class salaryinfo;
}

class salaryinfo : public QWidget//职工相应扣税显示窗口
{
    Q_OBJECT

public:
    explicit salaryinfo(QWidget *parent = nullptr);
    ~salaryinfo();

private slots:
    void on_close_clicked();//点击“取消”关闭窗口

    void process_salaryInfo(worker);//显示当前员工工资槽函数

private:
    Ui::salaryinfo *ui;
};

#endif // SALARYINFO_H
