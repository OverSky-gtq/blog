////////////////////
///主窗口
//时间：2021 7、21
//创作者：王景祺
///用途：进行职工信息的管理
/// ///////////////////

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QAction"
#include "addworker.h"
#include "filchoose.h"
#include "worker.h"
#include "QDebug"
#include "workersalary.h"
#include "QFile"
#include "QTextCodec"
#include "info.h"
#include "QMessageBox"
#include "login.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);



    //设置表格抬头
    ui->tableWidget->setColumnCount(6);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList()<<"姓名"<<"工号"<<"年龄"<<"入职日期"<<"电话"<<"住址");


    //新建员工月工资窗口
    workersalary* WorkerSalary = new workersalary;

    //通过connect实现点击转到员工月工资窗口
    connect(this->ui->tableWidget,SIGNAL(cellDoubleClicked(int,int)),WorkerSalary,SLOT(open(int,int)));

    //通过connect实现点击表格后将选择的worker作为信号发送出去
    connect(this->ui->tableWidget,SIGNAL(cellDoubleClicked(int,int)),this,SLOT(mainwindow_proess_workersalary(int,int)));

    //通过connect实现workersalary窗口接收发送的选择的员工
    connect(this,SIGNAL(sendworker(worker)),WorkerSalary,SLOT(widget_process_worker(worker)));

    //通过connect实现将修改的职工发回主窗口并显示
    connect(WorkerSalary,SIGNAL(sendData_2(worker,int)),this,SLOT(process_changeworker(worker,int)));

    //传回要删除的职工位置进行删除操作
    connect(WorkerSalary,SIGNAL(sendDate_row(int)),this,SLOT(process_deleteworker(int)));


}

MainWindow::~MainWindow()
{

    delete ui;

}



//新增对职工基本信息的输入窗口
void MainWindow::on_Add_triggered()
{
    //打开新增员工窗口
    Addworker *workerAdd=new Addworker;
    workerAdd->show();


    //通过connect实现发送新增worker后传入主窗口接收
    connect(workerAdd,SIGNAL(sendData(worker)),this,SLOT(process_addworker(worker)));

}

//单击"读取文件"打开文件读取窗口
void MainWindow::on_Load_triggered()
{
    FilChoose *filechoose=new FilChoose;


    //接收选择文件的路径
    connect(filechoose,SIGNAL(sendpath(QString)),this,SLOT(process_loadoperation(QString)));
    filechoose->show();
}



//接收新增的worker放入容器并显示 无返回值，传入worker_input，储存了新增职工的信息
void MainWindow::process_addworker(worker worker_input)
{
    //worker_main_temp赋值
   this->worker_main_temp=worker_input;


    //压入容器
   this->main_Vector_worker.push_back((worker_main_temp));


    //计数加一
   (this->main_int_CountWorker)++;


    //制表
   this->ui->tableWidget->setRowCount(main_int_CountWorker);
    ui->tableWidget->setItem((main_int_CountWorker-1),0,new QTableWidgetItem(worker_input.m_Qs_name));//姓名
    ui->tableWidget->setItem((main_int_CountWorker-1),1,new QTableWidgetItem(worker_input.m_Qs_number));//工号
    ui->tableWidget->setItem((main_int_CountWorker-1),2,new QTableWidgetItem(worker_input.m_Qs_age));//年龄
    ui->tableWidget->setItem((main_int_CountWorker-1),3,new QTableWidgetItem(worker_input.m_Qs_begindate));//入职日期
    ui->tableWidget->setItem((main_int_CountWorker-1),4,new QTableWidgetItem(worker_input.m_Qs_phone));//电话
    ui->tableWidget->setItem((main_int_CountWorker-1),5,new QTableWidgetItem(worker_input.m_Qs_address));//地址

}


//发送worker类信号 row与col为鼠标点击的所在排数与列数以此来判断用户点击的是哪个职工
void MainWindow::mainwindow_proess_workersalary(int row, int col)
{
    //发送选择的职工
    emit sendworker(this->main_Vector_worker[row]);
}

//接受更改的worker信息并改变容器里的元素并重新制表 w为更改的职工worker row为其所在的位置即第几排
void MainWindow::process_changeworker(worker w,int row)
{
   //更改容器内的相应元素
   main_Vector_worker[row]=w;


   //制表
   ui->tableWidget->setItem(row,0,new QTableWidgetItem(w.m_Qs_name));//姓名
   ui->tableWidget->setItem(row,1,new QTableWidgetItem(w.m_Qs_number));//工号
   ui->tableWidget->setItem(row,2,new QTableWidgetItem(w.m_Qs_age));//年龄
   ui->tableWidget->setItem(row,3,new QTableWidgetItem(w.m_Qs_begindate));//入职日期
   ui->tableWidget->setItem(row,4,new QTableWidgetItem(w.m_Qs_phone));//电话
   ui->tableWidget->setItem(row,5,new QTableWidgetItem(w.m_Qs_address));//地址
}

//接收删除信号对容器里的特定worker删除并重新制表 n为删除的员工位置
void MainWindow::process_deleteworker(int n)
{
    QVector<worker>::iterator QVector_iter=main_Vector_worker.begin();
    QVector_iter+=n;
    main_Vector_worker.erase(QVector_iter);
    main_int_CountWorker--;
    this->ui->tableWidget->setRowCount(this->main_int_CountWorker);


    //刷新表格
    for(int n=0;n<main_int_CountWorker;n++)
    {
        worker_main_temp=main_Vector_worker[n];
        ui->tableWidget->setItem(n,0,new QTableWidgetItem(worker_main_temp.m_Qs_name));//姓名
        ui->tableWidget->setItem(n,1,new QTableWidgetItem(worker_main_temp.m_Qs_number));//工号
        ui->tableWidget->setItem(n,2,new QTableWidgetItem(worker_main_temp.m_Qs_age));//年龄
        ui->tableWidget->setItem(n,3,new QTableWidgetItem(worker_main_temp.m_Qs_begindate));//入职日期
        ui->tableWidget->setItem(n,4,new QTableWidgetItem(worker_main_temp.m_Qs_phone));//电话
        ui->tableWidget->setItem(n,5,new QTableWidgetItem(worker_main_temp.m_Qs_address));//地址
    }
}





//点击保存后将容器里写入的worker全部写入txt
void MainWindow::on_Save_triggered()
{
    //打开文件
    QFile file("C:\\Users\\wangj\\Documents\\workersalary\\1.txt");
        if(! file.open(QIODevice::WriteOnly|QIODevice::Text))
        {
            return;
        }


        //按行写入文件
        QTextStream out(&file);
        for(int n=0;n<main_int_CountWorker;n++)
        {

            //基本信息
            out<<main_Vector_worker[n].m_Qs_name<<endl<<main_Vector_worker[n].m_Qs_number<<endl<<main_Vector_worker[n].m_Qs_phone<<endl<<main_Vector_worker[n].m_Qs_age<<endl<<main_Vector_worker[n].m_Qs_begindate<<endl<<main_Vector_worker[n].m_Qs_address<<endl;


            //各类工资信息
            for(int i=0;i<OneYear;i++)
            {
                out<<main_Vector_worker[n].salary.m_Qs_basicsalary[i]<<endl;
            }
            for(int i=0;i<OneYear;i++)
            {
                out<<main_Vector_worker[n].salary.m_Qs_jobssalary[i]<<endl;
            }
            for(int i=0;i<OneYear;i++)
            {
                out<<main_Vector_worker[n].salary.m_Qs_agesalary[i]<<endl;
            }
            for(int i=0;i<OneYear;i++)
            {
                out<<main_Vector_worker[n].salary.m_Qs_allowance[i]<<endl;
            }
            for(int i=0;i<OneYear;i++)
            {
                out<<main_Vector_worker[n].salary.m_Qs_housing[i]<<endl;
            }
            for(int i=0;i<OneYear;i++)
            {
                out<<main_Vector_worker[n].salary.m_Qs_Trafficsubsidies[i]<<endl;
            }
            for(int i=0;i<OneYear;i++)
            {
                out<<main_Vector_worker[n].salary.m_Qs_Dutytostick[i]<<endl;
            }
            out<<main_Vector_worker[n].path_picture<<endl;
        }
        file.close();


        //清空容器与表格
        main_Vector_worker.clear();
        main_int_CountWorker=0;
        this->ui->tableWidget->setRowCount(main_int_CountWorker);
        QMessageBox::information(this,"SUCCESS","保存成功");
}



//接收到选择的文件路径后打开并读取文件信息并放入容器且显示 path为选择文件的路径
void MainWindow::process_loadoperation(QString path)
{
    //清空容器与表格
    main_Vector_worker.clear();
    main_int_CountWorker=0;
    this->ui->tableWidget->setRowCount(main_int_CountWorker);
    QFile File(path);
    File.open(QIODevice::ReadWrite);
    QByteArray read_line;
    QTextCodec *codec = QTextCodec::codecForName("GBK");


    //一直读取直到文件读完先写入worker_main_temp再将之放入容器
    while(!File.atEnd())
    {

        //读取基本信息
        read_line=File.readLine();
        read_line=read_line.left(read_line.length()-2);
        QString str_name = codec->toUnicode(read_line);
        qDebug()<<str_name;
        worker_main_temp.m_Qs_name=str_name;
        read_line=File.readLine();
        read_line=read_line.left(read_line.length()-2);
        worker_main_temp.m_Qs_number=read_line;
        read_line=File.readLine();
        read_line=read_line.left(read_line.length()-2);
        worker_main_temp.m_Qs_phone=read_line;
        read_line=File.readLine();
        read_line=read_line.left(read_line.length()-2);
        worker_main_temp.m_Qs_age=read_line;
        read_line=File.readLine();
        read_line=read_line.left(read_line.length()-2);
        worker_main_temp.m_Qs_begindate=read_line;
        read_line=File.readLine();
        read_line=read_line.left(read_line.length()-2);
        QString str_address = codec->toUnicode(read_line);
        worker_main_temp.m_Qs_address=str_address;

        //读取各类工资信息
        for(int n=0;n<OneYear;n++)
        {
             read_line=File.readLine();
             read_line=read_line.left(read_line.length()-2);
             worker_main_temp.salary.m_Qs_basicsalary[n]=read_line;
        }
        for(int n=0;n<OneYear;n++)
        {
             read_line=File.readLine();
             read_line=read_line.left(read_line.length()-2);
             worker_main_temp.salary.m_Qs_jobssalary[n]=read_line;
        }
        for(int n=0;n<OneYear;n++)
        {
             read_line=File.readLine();
             read_line=read_line.left(read_line.length()-2);
             worker_main_temp.salary.m_Qs_agesalary[n]=read_line;
        }
        for(int n=0;n<OneYear;n++)
        {
             read_line=File.readLine();
             read_line=read_line.left(read_line.length()-2);
             worker_main_temp.salary.m_Qs_allowance[n]=read_line;
        }
        for(int n=0;n<OneYear;n++)
        {
             read_line=File.readLine();
             read_line=read_line.left(read_line.length()-2);
             worker_main_temp.salary.m_Qs_housing[n]=read_line;
        }
        for(int n=0;n<OneYear;n++)
        {
             read_line=File.readLine();
             read_line=read_line.left(read_line.length()-2);
             worker_main_temp.salary.m_Qs_Trafficsubsidies[n]=read_line;
        }
        for(int n=0;n<OneYear;n++)
        {
             read_line=File.readLine();
             read_line=read_line.left(read_line.length()-2);
             worker_main_temp.salary.m_Qs_Dutytostick[n]=read_line;
        }
        read_line=File.readLine();
        read_line=read_line.left(read_line.length()-2);
        worker_main_temp.path_picture=read_line;
        //读取一个worker完毕放入容器
        main_Vector_worker.push_back(worker_main_temp);
        main_int_CountWorker++;

    }
    //制表
    this->ui->tableWidget->setRowCount(this->main_int_CountWorker);
    for(int n=0;n<main_int_CountWorker;n++)
    {
        worker_main_temp=main_Vector_worker[n];
        ui->tableWidget->setItem(n,0,new QTableWidgetItem(worker_main_temp.m_Qs_name));
        ui->tableWidget->setItem(n,1,new QTableWidgetItem(worker_main_temp.m_Qs_number));
        ui->tableWidget->setItem(n,2,new QTableWidgetItem(worker_main_temp.m_Qs_age));
        ui->tableWidget->setItem(n,3,new QTableWidgetItem(worker_main_temp.m_Qs_begindate));
        ui->tableWidget->setItem(n,4,new QTableWidgetItem(worker_main_temp.m_Qs_phone));
        ui->tableWidget->setItem(n,5,new QTableWidgetItem(worker_main_temp.m_Qs_address));
    }
}

//打开使用说明窗口
void MainWindow::on_actioninfo_triggered()
{
    info* INFO=new info;
    INFO->show();
}


//登出
void MainWindow::on_actionexit_triggered()
{
    this->close();
    login *LOgin=new login;
    LOgin->show();
}



