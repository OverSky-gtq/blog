///////////////////
//注册窗口.h
//时间：2021 7、21
//创作者：王景祺
//进行用户名注册
///////////////////


#include "reg.h"
#include "ui_reg.h"
#include "QFile"
#include "QTextStream"

reg::reg(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::reg)
{
    ui->setupUi(this);
}

reg::~reg()
{
    delete ui;
}

//将注册的信息写入文件
void reg::on_reg_2_clicked()
{
    //打开文件
    QFile File("C:\\Users\\wangj\\Documents\\workersalary\\account\\accountandpassword.txt");
    File.open(QIODevice::Append);//选择Append写入方式
    QTextStream out(&File);
    out<<ui->lineEdit->displayText()<<endl;
    out<<ui->lineEdit_2->displayText()<<endl;
    this->close();
    this->~reg();
}

//点击取消关闭窗口
void reg::on_pushButton_2_clicked()
{
    this->close();
    this->~reg();
}
