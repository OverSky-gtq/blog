/////////////////////////////////////////////
//文件名：addworker
//新增员工头文件
//时间：2021 7、21
//创作者：王景祺
//用途：新增员工的输入窗口
////////////////////////////////////////////



#ifndef ADDWORKER_H
#define ADDWORKER_H
#include <QWidget>
#include "worker.h"

namespace Ui {
class Addworker;
}

class Addworker : public QWidget  //对职工基本信息的输入窗口
{
    Q_OBJECT

public:
    explicit Addworker(QWidget *parent = nullptr);
    ~Addworker();
    QString path_add_temp;

signals:
    void sendData(worker);//worker信号

private slots:
    void on_cancel_clicked();//点击"取消"关闭窗口

    void on_Save_clicked();//点击"保存"对输入职工进行保存

    void process_SIGNALchangebasic(worker);//发送一个worker信号用以添加add界面lineedit的内容

private:
    Ui::Addworker *ui;
};

#endif // ADDWORKER_H
