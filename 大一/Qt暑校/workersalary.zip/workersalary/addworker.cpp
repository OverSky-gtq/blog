/////////////////////////////////////////////
//新增员工头文件
//时间：2021 7、21
//创作者：王景祺
//用途：新增员工的输入窗口
////////////////////////////////////////////

#include "addworker.h"
#include "ui_addworker.h"
#include "QDebug"
#include "worker.h"
#include "mainwindow.h"
#include "QFile"
#include "QMessageBox"

Addworker::Addworker(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Addworker)
{
    ui->setupUi(this);
    ui->dateEdit->setCalendarPopup(true);//显示日历
}

Addworker::~Addworker()
{
    qDebug()<<"addworker析构";
    delete ui;
}


//点击“取消”关闭窗口
void Addworker::on_cancel_clicked()
{
    this->close();
}


//点击保存后发送一个更改后的worker类信号由主窗口进行接收    无返回值
void Addworker::on_Save_clicked()
{


    //将输入的worker信息传给worker_temp
    worker worker_temp;
    QDate current_date =QDate::currentDate();
    QDate date= ui->dateEdit->date();



    //判断输入的信息是否完整
    if(ui->Addname->text().isEmpty()==true||ui->Addaddress->text().isEmpty()==true||ui->Addage->text().isEmpty()==true||ui->Addnumber->text().isEmpty()==true||ui->Addphone->text().isEmpty()==true)
    {
       QMessageBox::critical(this,"错误","未输入完整信息");
    }



    //判断输入的年龄与手机是否正确
   else if(ui->Addage->displayText().toInt()<=0||ui->Addage->displayText().toInt()>=100)
    {
       QMessageBox::critical(this,"错误","错误的年龄或手机号输入");
    }



    //判断输入的时间是否超过当前时间或在1940年以前
    else if(date.year()>current_date.year()||date.year()<=1940)
    {
        QMessageBox::critical(this,"错误","错误时间输入");
    }
    else if(date.year()==current_date.year()&&date.month()>current_date.month())
    {
        QMessageBox::critical(this,"错误","错误时间输入");
    }
    else if(date.year()==current_date.year()&&date.month()==current_date.month()&&date.day()>current_date.day())
    {
        QMessageBox::critical(this,"错误","错误时间输入");
    }
    else
    {



        //将输入的值赋给 worker_temp进行储存
        worker_temp.m_Qs_name=ui->Addname->displayText();       //姓名
        worker_temp.m_Qs_number=ui->Addnumber->displayText();      //工号
        QString Begindate=date.toString("yyyy-MM-dd");    //转为QString
        worker_temp.m_Qs_begindate=Begindate;         //入职时间
        worker_temp.m_Qs_address=ui->Addaddress->displayText();    //地址
        worker_temp.m_Qs_phone=ui->Addphone->displayText();   //手机号
        worker_temp.m_Qs_age=ui->Addage->displayText();    //年龄
        worker_temp.path_picture=path_add_temp;

        //发送信号
        emit sendData(worker_temp);
        this->close();
        this->~Addworker();
    }
}





//后续更改时add窗口显示原来的信息  传入worker类w无返回值
//w内储存了保存的职工信息用于显示
void Addworker::process_SIGNALchangebasic(worker w)
{
    path_add_temp=w.path_picture;
    this->ui->Addname->setText(w.m_Qs_name);//显示姓名
    this->ui->Addage->setText(w.m_Qs_age);//显示年龄
    this->ui->Addnumber->setText(w.m_Qs_number);//显示工号
    this->ui->Addphone->setText(w.m_Qs_phone);//显示手机号
    this->ui->Addaddress->setText(w.m_Qs_address);//显示地址
}
