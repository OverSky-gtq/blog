///////////////////////
//使用说明窗口
//时间：2021 7、21
//创作者：王景祺
///////////////////////


#ifndef INFO_H
#define INFO_H

#include <QWidget>

namespace Ui {
class info;
}

class info : public QWidget//使用说明窗口
{
    Q_OBJECT

public:
    explicit info(QWidget *parent = nullptr);
    ~info();

private slots:
    void on_close_clicked();

private:
    Ui::info *ui;
};

#endif // INFO_H
