//////////////////////////////
/////基本职工worker类
//时间：2021 7、21
//创作者：王景祺
/// 用于储存各类职工信息
/// //////////////////////////




#ifndef WORKER_H
#define WORKER_H
#include "QString"
#include "salary.h"

class worker//自定义职工类
{
public:
    worker();
    QString m_Qs_name="";//职工姓名
    QString m_Qs_number="";//职工工号
    QString m_Qs_phone="";//职工电话
    QString m_Qs_address="";//职工地址
    QString m_Qs_begindate="";//职工入职日期
    QString m_Qs_age=0;//职工年龄
    Salary salary;//职工的工资类
    QString path_picture;//用于储存头像的路径
};



#endif // WORKER_H
