///////////////////////
//使用说明窗口
//时间：2021 7、21
//创作者：王景祺
///////////////////////

#include "info.h"
#include "ui_info.h"

info::info(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::info)
{
    ui->setupUi(this);
    ui->IFo->setText("欢迎使用本软件");
    ui->IFo->append("点击新增进行员工列表的新增，新增后双击员工可进行信息修改和月工资信息显示");
}

info::~info()
{
    delete ui;
}

void info::on_close_clicked()
{
    this->close();
    this->~info();
}
