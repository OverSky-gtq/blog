/////////////////////////////
//职工月工资类
//时间：2021 7、21
//创作者：王景祺
//用途：用于记录职工的各类月工资
/////////////////////////////




#ifndef SALARY_H
#define SALARY_H
#include "QString"
#define OneYear 12

class Salary//职工各类工资信息
{
public:
    Salary();
     QString m_Qs_basicsalary[OneYear]={"0","0","0","0","0","0","0","0","0","0","0","0"};//基本工资，每个月的工资
     QString m_Qs_jobssalary[OneYear]={"0","0","0","0","0","0","0","0","0","0","0","0"};//岗位工资，每个月的工资
     QString m_Qs_agesalary[OneYear]={"0","0","0","0","0","0","0","0","0","0","0","0"};//工龄工资，每个月的工资
     QString m_Qs_allowance[OneYear]={"0","0","0","0","0","0","0","0","0","0","0","0"};//津贴，每个月的工资
     QString m_Qs_housing[OneYear]={"0","0","0","0","0","0","0","0","0","0","0","0"};// 房贴，每个月的工资
     QString m_Qs_Trafficsubsidies[OneYear]={"0","0","0","0","0","0","0","0","0","0","0","0"};//交通补贴，每个月的工资
     QString m_Qs_Dutytostick[OneYear]={"0","0","0","0","0","0","0","0","0","0","0","0"};//岗贴，每个月的工资
};

#endif // SALARY_H
