/////////////////////////////////////////////
//更改员工月工资窗口
//时间：2021 7、21
//创作者：王景祺
//用途：更改员工月工资窗口
////////////////////////////////////////////



#ifndef CHANGEWORKERSALARY_H
#define CHANGEWORKERSALARY_H
#include "worker.h"

#include <QWidget>

namespace Ui {
class changeworkersalary;
}

class changeworkersalary : public QWidget//更改职工月工资窗口
{
    Q_OBJECT

public:
    explicit changeworkersalary(QWidget *parent = nullptr);
    ~changeworkersalary();
    Salary change_salary;//用于储存传入的工资信息

signals:
    void sendsalary(Salary);//Salary信号

private slots:
    void on_cancel_clicked();//关闭窗口

    void changeworkersalaryimple(worker,int);//接收worker的槽函数

    void on_save_clicked();//保存发送salary信号

private:
    Ui::changeworkersalary *ui;
};

#endif // CHANGEWORKERSALARY_H
