//////////////////////////////
///职工详细信息显示
//时间：2021 7、21
//创作者：王景祺
/// 用途：可对职工的姓名，工号，电话，住址进行相关展示
/// /////////////////////////

#include "workersalary.h"
#include "ui_workersalary.h"
#include "QDebug"
#include "addworker.h"
#include "changeworkersalary.h"
#include "salaryinfo.h"
#include "QMessageBox"
#include "filchoose.h"
#include "QFileDialog"

workersalary::workersalary(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::workersalary)
{
    ui->setupUi(this);
    //两个表格不可编辑
    this->ui->salrytable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    this->ui->workerbasic->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

workersalary::~workersalary()
{
    qDebug()<<"workersalary析构";
    delete ui;
}

//双击表格后打开详细信息表格 row与col为鼠标点击的所在行数与列数用于定位
void workersalary::open(int row,int col)
{
    //制表
    row_salary=row;
    ui->workerbasic->setColumnCount(6);
    ui->workerbasic->setRowCount(1);
    ui->workerbasic->setHorizontalHeaderLabels(QStringList()<<"姓名"<<"工号"<<"年龄"<<"入职日期"<<"电话"<<"住址");
    this->ui->salrytable->setColumnCount(7);
    this->ui->salrytable->setRowCount(12);
    this->ui->salrytable->setVerticalHeaderLabels(QStringList()<<"一月"<<"二月"<<"三月"<<"四月"<<"五月"<<"六月"<<"七月"<<"八月"<<"九月"<<"十月"<<"十一月"<<"十二月");
    this->ui->salrytable->setHorizontalHeaderLabels(QStringList()<<"基本工资"<<"岗位工资"<<"工龄工资"<<"津贴"<<"补贴"<<"房贴"<<"交通补贴");
    this->show();
}

//显示职工的基本信息 w为传入的worker类用于储存职工信息
void workersalary::widget_process_worker(worker w)
{
    //显示基本信息
        salary_worker_temp=w;
        ui->workerbasic->setItem(0,0,new QTableWidgetItem(w.m_Qs_name));
        ui->workerbasic->setItem(0,1,new QTableWidgetItem(w.m_Qs_number));
        ui->workerbasic->setItem(0,2,new QTableWidgetItem(w.m_Qs_age));
        ui->workerbasic->setItem(0,3,new QTableWidgetItem(w.m_Qs_begindate));
        ui->workerbasic->setItem(0,4,new QTableWidgetItem(w.m_Qs_phone));
        ui->workerbasic->setItem(0,5,new QTableWidgetItem(w.m_Qs_address));


        //显示工资信息制表
        for(int n=0;n<12;n++)
        {
            this->ui->salrytable->setItem(n,0,new QTableWidgetItem(w.salary.m_Qs_basicsalary[n]));
        }
        for(int n=0;n<12;n++)
        {
            this->ui->salrytable->setItem(n,1,new QTableWidgetItem(w.salary.m_Qs_jobssalary[n]));
        }
        for(int n=0;n<12;n++)
        {
            this->ui->salrytable->setItem(n,2,new QTableWidgetItem(w.salary.m_Qs_agesalary[n]));
        }
        for(int n=0;n<12;n++)
        {
            this->ui->salrytable->setItem(n,3,new QTableWidgetItem(w.salary.m_Qs_allowance[n]));
        }
        for(int n=0;n<12;n++)
        {
            this->ui->salrytable->setItem(n,4,new QTableWidgetItem(w.salary.m_Qs_Dutytostick[n]));
        }
        for(int n=0;n<12;n++)
        {
            this->ui->salrytable->setItem(n,5,new QTableWidgetItem(w.salary.m_Qs_housing[n]));
        }
        for(int n=0;n<12;n++)
        {
            this->ui->salrytable->setItem(n,6,new QTableWidgetItem(w.salary.m_Qs_Trafficsubsidies[n]));
        }


        //显示头像
        QPixmap *pixmap = new QPixmap(salary_worker_temp.path_picture);
        pixmap->scaled(ui->picture->size(), Qt::KeepAspectRatio);
        ui->picture->setScaledContents(true);
        ui->picture->setPixmap(*pixmap);

}



//点击修改基本信息后打开修改信息窗口
void workersalary::on_Basicchange_clicked()
{
    Addworker* workeradd_2=new Addworker;


    //通过connect实现在addworker窗口显示原来的信息
    connect(this,SIGNAL(sendworkerforchange(worker)),workeradd_2,SLOT(process_SIGNALchangebasic(worker)));
    emit sendworkerforchange(salary_worker_temp);
    workeradd_2->show();


    //更改信息后重新制表并更改salary_worker_temp
    connect(workeradd_2,SIGNAL(sendData(worker)),this,SLOT(process_changeworker_s(worker)));
}



//修改职工基本信息槽函数 w为修改后的worker类储存修改后的信息
void workersalary::process_changeworker_s(worker w)
{
    //重新制表
    salary_worker_temp=w;
    ui->workerbasic->setItem(0,0,new QTableWidgetItem(w.m_Qs_name));
    ui->workerbasic->setItem(0,1,new QTableWidgetItem(w.m_Qs_number));
    ui->workerbasic->setItem(0,2,new QTableWidgetItem(w.m_Qs_age));
    ui->workerbasic->setItem(0,3,new QTableWidgetItem(w.m_Qs_begindate));
    ui->workerbasic->setItem(0,4,new QTableWidgetItem(w.m_Qs_phone));
    ui->workerbasic->setItem(0,5,new QTableWidgetItem(w.m_Qs_address));


    //发送w 与row——salary给主窗口  w为信息储存  row——salary为职工所在位置
    emit sendData_2(w,row_salary);
}



//接收更改工资后的salary类修改工资信息后重新制表并更改salary_worker_temp再将更改的worker传回主窗口  s为salary类用于储存工资信息
void workersalary::process_changesalary_s(Salary s)
{
    //制表
    salary_worker_temp.salary=s;
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,0,new QTableWidgetItem(s.m_Qs_basicsalary[n]));
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,1,new QTableWidgetItem(s.m_Qs_jobssalary[n]));
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,2,new QTableWidgetItem(s.m_Qs_agesalary[n]));
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,3,new QTableWidgetItem(s.m_Qs_allowance[n]));
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,4,new QTableWidgetItem(s.m_Qs_Dutytostick[n]));
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,5,new QTableWidgetItem(s.m_Qs_housing[n]));
    }
    for(int n=0;n<OneYear;n++)
    {
        this->ui->salrytable->setItem(n,6,new QTableWidgetItem(s.m_Qs_Trafficsubsidies[n]));
    }


    //发送更改后的worker与其所在位置
    emit sendData_2(salary_worker_temp,row_salary);
}


//打开修改工资信息窗口
void workersalary::on_Salarychange_clicked()
{
    changeworkersalary* Changeworkersalary=new changeworkersalary;
    //实现worker
    connect(this,SIGNAL(sendData_2(worker,int)),Changeworkersalary,SLOT(changeworkersalaryimple(worker,int)));
    connect(Changeworkersalary,SIGNAL(sendsalary(Salary)),this,SLOT(process_changesalary_s(Salary)));
    emit sendData_2(salary_worker_temp,row_salary);
    Changeworkersalary->show();
}

//发送删除信号
void workersalary::on_delete_2_clicked()
{
    emit sendDate_row(row_salary);
    this->close();
}


//打开实发数窗口
void workersalary::on_salaryinfo_clicked()
{
    salaryinfo* SlrInfo=new salaryinfo;
    connect(this,SIGNAL(sendworkerforchange(worker)),SlrInfo,SLOT(process_salaryInfo(worker)));

    //发送需要显示的worker用其成员类salary显示工资
    emit sendworkerforchange(salary_worker_temp);
    SlrInfo->show();
}


//读取图片并显示
void workersalary::on_loadpicture_clicked()
{
    //获取图片所在路径
    salary_worker_temp.path_picture = QFileDialog::getOpenFileName(this,"打开文件","C:\\Users\\wangj\\Documents\\workersalary\\picture") ;
    QPixmap *pixmap = new QPixmap(salary_worker_temp.path_picture);
    pixmap->scaled(ui->picture->size(), Qt::KeepAspectRatio);
    ui->picture->setScaledContents(true);
    ui->picture->setPixmap(*pixmap);
    delete pixmap;
    emit sendData_2(salary_worker_temp,row_salary);
}
